#ifndef __LED_H
#define __LED_H
 
#include "sys.h"
 
#define LED0 PAout(1)// PA1
 
void LED_Init(void);
 
 
#endif
